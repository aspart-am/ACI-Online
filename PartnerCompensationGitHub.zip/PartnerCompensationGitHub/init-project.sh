#!/bin/bash

# Script to initialize the project

echo "Initializing Partner Compensation GitHub Pages project..."

# Create a new git repository
echo "Initializing git repository..."
git init

# Install dependencies
echo "Installing dependencies..."
npm install

# Create a first commit
echo "Creating initial commit..."
git add .
git commit -m "Initial commit"

echo "Project initialized successfully!"
echo ""
echo "Next steps:"
echo "1. Create a new repository on GitHub"
echo "2. Link this local repository to your GitHub repository:"
echo "   git remote add origin https://github.com/your-username/PartnerCompensationGitHub.git"
echo "   git branch -M main"
echo "   git push -u origin main"
echo ""
echo "3. Test the application locally:"
echo "   ./test-local.sh"
echo ""
echo "4. Deploy to GitHub Pages:"
echo "   ./deploy-to-github.sh"
echo ""
echo "Note: Make sure to update the BASE_URL in vite.config.ts if your repository name is different."
