# Partner Compensation - GitHub Pages Version

Cette application est une version adaptée pour GitHub Pages de l'application PartnerCompensation, conçue pour gérer les indicateurs ACI (Accord Conventionnel Interprofessionnel) pour les professionnels de santé.

## Fonctionnalités

- Gestion des indicateurs ACI (core et optionnels)
- Gestion des associés (professionnels de santé)
- Attribution de missions (indicateurs) aux associés
- Suivi de la progression et des compensations
- Tableau de bord avec statistiques

## Technologies utilisées

- React
- TypeScript
- TailwindCSS
- React Query
- Wouter (pour le routage)
- LocalStorage (pour la persistance des données)

## Différences avec la version originale

Cette version a été adaptée pour fonctionner entièrement côté client, sans nécessiter de serveur backend :

- Utilisation de localStorage au lieu d'une base de données
- Routage basé sur les hash pour la compatibilité avec GitHub Pages
- Configuration adaptée pour le déploiement sur GitHub Pages

## Installation et démarrage en local

1. Clonez ce dépôt
   ```bash
   git clone https://github.com/votre-username/PartnerCompensationGitHub.git
   cd PartnerCompensationGitHub
   ```

2. Installez les dépendances
   ```bash
   npm install
   ```

3. Lancez l'application en mode développement
   ```bash
   npm run dev
   ```

4. Ouvrez votre navigateur à l'adresse [http://localhost:5173](http://localhost:5173)

## Construction pour la production

Pour construire l'application pour la production :

```bash
npm run build
```

Les fichiers de production seront générés dans le dossier `dist`.

## Déploiement sur GitHub Pages

### Option 1 : Déploiement automatique

Cette application est configurée pour se déployer automatiquement sur GitHub Pages à chaque push sur la branche main, grâce au workflow GitHub Actions inclus.

1. Créez un nouveau dépôt sur GitHub
2. Poussez ce code vers votre dépôt
3. Dans les paramètres de votre dépôt GitHub, activez GitHub Pages et sélectionnez la source "GitHub Actions"
4. Le déploiement se fera automatiquement à chaque push sur la branche main

### Option 2 : Déploiement manuel

Vous pouvez également déployer manuellement l'application :

1. Construisez l'application
   ```bash
   npm run build
   ```

2. Déployez le contenu du dossier `dist` sur GitHub Pages en utilisant gh-pages
   ```bash
   npm install -g gh-pages
   gh-pages -d dist
   ```

## Configuration

Si vous déployez l'application sous un nom de dépôt différent, vous devrez modifier la variable `BASE_URL` dans le fichier `vite.config.ts` pour qu'elle corresponde au nom de votre dépôt :

```typescript
// Dans vite.config.ts
const BASE_URL = "/votre-nom-de-repo/";
```

## Persistance des données

Toutes les données sont stockées dans le localStorage du navigateur. Cela signifie que :

- Les données sont persistantes entre les sessions de navigation
- Les données sont spécifiques à chaque navigateur et appareil
- Les données peuvent être effacées si l'utilisateur vide son cache ou ses données de navigation

## Licence

MIT
