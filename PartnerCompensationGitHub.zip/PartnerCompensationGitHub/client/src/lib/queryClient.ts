import { QueryClient, QueryFunction } from "@tanstack/react-query";
import { apiService } from "../services/apiService";

// This function is kept for compatibility but won't be used in the same way
async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

// Modified to use our apiService instead of fetch
export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<any> {
  // Parse the URL to determine which API endpoint to call
  const endpoint = url.split('/').pop() || '';
  const id = url.match(/\/(\d+)$/)?.[1];
  
  try {
    // Handle different API endpoints
    if (url.includes('/api/indicators')) {
      if (method === 'GET') {
        if (id) {
          return { json: async () => apiService.getIndicator(Number(id)) };
        } else {
          return { json: async () => apiService.getIndicators() };
        }
      } else if (method === 'POST') {
        return { json: async () => apiService.createIndicator(data as any) };
      } else if (method === 'PATCH' && id) {
        return { json: async () => apiService.updateIndicator(Number(id), data as any) };
      }
    } else if (url.includes('/api/associates')) {
      if (method === 'GET') {
        if (id) {
          return { json: async () => apiService.getAssociate(Number(id)) };
        } else if (url.includes('/missions')) {
          const associateId = url.match(/\/associates\/(\d+)\/missions/)?.[1];
          if (associateId) {
            return { json: async () => apiService.getMissionsByAssociate(Number(associateId)) };
          }
        } else {
          return { json: async () => apiService.getAssociates() };
        }
      } else if (method === 'POST') {
        return { json: async () => apiService.createAssociate(data as any) };
      } else if (method === 'PATCH' && id) {
        return { json: async () => apiService.updateAssociate(Number(id), data as any) };
      } else if (method === 'DELETE' && id) {
        return { json: async () => apiService.deleteAssociate(Number(id)) };
      }
    } else if (url.includes('/api/missions')) {
      if (method === 'GET') {
        if (id) {
          return { json: async () => apiService.getMission(Number(id)) };
        } else {
          return { json: async () => apiService.getMissions() };
        }
      } else if (method === 'POST') {
        return { json: async () => apiService.createMission(data as any) };
      } else if (method === 'PATCH' && id) {
        return { json: async () => apiService.updateMission(Number(id), data as any) };
      } else if (method === 'DELETE' && id) {
        return { json: async () => apiService.deleteMission(Number(id)) };
      }
    } else if (url.includes('/api/stats')) {
      return { json: async () => apiService.getStats() };
    } else if (url.includes('/api/dashboard')) {
      return { json: async () => apiService.getDashboard() };
    }
    
    throw new Error(`Unhandled API request: ${method} ${url}`);
  } catch (error) {
    console.error('API request error:', error);
    throw error;
  }
}

type UnauthorizedBehavior = "returnNull" | "throw";

// Modified to use our apiService instead of fetch
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const url = queryKey[0] as string;
    
    try {
      // Parse the URL to determine which API endpoint to call
      if (url.includes('/api/indicators')) {
        const id = url.match(/\/indicators\/(\d+)$/)?.[1];
        if (id) {
          return await apiService.getIndicator(Number(id));
        } else {
          return await apiService.getIndicators();
        }
      } else if (url.includes('/api/associates')) {
        const id = url.match(/\/associates\/(\d+)$/)?.[1];
        if (id) {
          if (url.includes('/missions')) {
            return await apiService.getMissionsByAssociate(Number(id));
          } else {
            return await apiService.getAssociate(Number(id));
          }
        } else {
          return await apiService.getAssociates();
        }
      } else if (url.includes('/api/missions')) {
        const id = url.match(/\/missions\/(\d+)$/)?.[1];
        if (id) {
          return await apiService.getMission(Number(id));
        } else {
          return await apiService.getMissions();
        }
      } else if (url.includes('/api/stats')) {
        return await apiService.getStats();
      } else if (url.includes('/api/dashboard')) {
        return await apiService.getDashboard();
      }
      
      throw new Error(`Unhandled API request: ${url}`);
    } catch (error) {
      console.error('Query function error:', error);
      if (unauthorizedBehavior === "returnNull") {
        return null;
      }
      throw error;
    }
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
