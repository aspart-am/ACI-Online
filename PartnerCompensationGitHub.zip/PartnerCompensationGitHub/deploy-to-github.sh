#!/bin/bash

# Script to deploy the application to GitHub Pages

echo "Building the application..."
npm run build

echo "Deploying to GitHub Pages..."
npm run deploy

echo "Deployment complete!"
echo "Your application should be available at: https://[your-username].github.io/PartnerCompensationGitHub/"
echo "Note: Replace [your-username] with your actual GitHub username."
echo "It may take a few minutes for the changes to be visible."
