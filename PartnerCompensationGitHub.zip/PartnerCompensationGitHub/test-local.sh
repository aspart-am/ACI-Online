#!/bin/bash

# Script to test the application locally

echo "Installing dependencies..."
npm install

echo "Starting development server..."
npm run dev

# The script will keep running until the user stops it with Ctrl+C
