import { localStorageService } from './localStorageService';
import type { 
  InsertIndicator, Indicator,
  InsertAssociate, Associate,
  InsertMission, Mission
} from '@shared/schema';

// API endpoints
const API_ENDPOINTS = {
  INDICATORS: '/api/indicators',
  ASSOCIATES: '/api/associates',
  MISSIONS: '/api/missions',
  STATS: '/api/stats',
  DASHBOARD: '/api/dashboard'
};

// Helper function to simulate network delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// API service that uses localStorage instead of making actual API calls
export const apiService = {
  // Indicators
  async getIndicators(): Promise<Indicator[]> {
    await delay(300); // Simulate network delay
    return localStorageService.getIndicators();
  },

  async getIndicator(id: number): Promise<Indicator | undefined> {
    await delay(200);
    return localStorageService.getIndicator(id);
  },

  async createIndicator(indicator: InsertIndicator): Promise<Indicator> {
    await delay(400);
    return localStorageService.createIndicator(indicator);
  },

  async updateIndicator(id: number, indicator: Partial<InsertIndicator>): Promise<Indicator | undefined> {
    await delay(400);
    return localStorageService.updateIndicator(id, indicator);
  },

  // Associates
  async getAssociates(): Promise<Associate[]> {
    await delay(300);
    return localStorageService.getAssociates();
  },

  async getAssociate(id: number): Promise<Associate | undefined> {
    await delay(200);
    return localStorageService.getAssociate(id);
  },

  async createAssociate(associate: InsertAssociate): Promise<Associate> {
    await delay(400);
    return localStorageService.createAssociate(associate);
  },

  async updateAssociate(id: number, associate: Partial<InsertAssociate>): Promise<Associate | undefined> {
    await delay(400);
    return localStorageService.updateAssociate(id, associate);
  },

  async deleteAssociate(id: number): Promise<boolean> {
    await delay(400);
    return localStorageService.deleteAssociate(id);
  },

  // Missions
  async getMissions(): Promise<Mission[]> {
    await delay(300);
    return localStorageService.getMissions();
  },

  async getMissionsByAssociate(associateId: number): Promise<Mission[]> {
    await delay(300);
    return localStorageService.getMissionsByAssociate(associateId);
  },

  async getMissionsByIndicator(indicatorId: number): Promise<Mission[]> {
    await delay(300);
    return localStorageService.getMissionsByIndicator(indicatorId);
  },

  async getMission(id: number): Promise<Mission | undefined> {
    await delay(200);
    return localStorageService.getMission(id);
  },

  async createMission(mission: InsertMission): Promise<Mission> {
    await delay(400);
    return localStorageService.createMission(mission);
  },

  async updateMission(id: number, mission: Partial<InsertMission>): Promise<Mission | undefined> {
    await delay(400);
    return localStorageService.updateMission(id, mission);
  },

  async deleteMission(id: number): Promise<boolean> {
    await delay(400);
    return localStorageService.deleteMission(id);
  },

  // Stats
  async getStats(): Promise<{
    totalCoreIndicators: number;
    validatedCoreIndicators: number;
    totalOptionalIndicators: number;
    validatedOptionalIndicators: number;
    fixedCompensation: number;
    maxFixedCompensation: number;
    variableCompensation: number;
    maxVariableCompensation: number;
  }> {
    await delay(300);
    return localStorageService.getStats();
  },

  // Dashboard
  async getDashboard(): Promise<{
    stats: {
      totalCoreIndicators: number;
      validatedCoreIndicators: number;
      totalOptionalIndicators: number;
      validatedOptionalIndicators: number;
      fixedCompensation: number;
      maxFixedCompensation: number;
      variableCompensation: number;
      maxVariableCompensation: number;
    };
    indicators: Indicator[];
    associates: Associate[];
    missions: Mission[];
  }> {
    await delay(500);
    const [stats, indicators, associates, missions] = await Promise.all([
      localStorageService.getStats(),
      localStorageService.getIndicators(),
      localStorageService.getAssociates(),
      localStorageService.getMissions()
    ]);

    return {
      stats,
      indicators,
      associates,
      missions
    };
  }
};
